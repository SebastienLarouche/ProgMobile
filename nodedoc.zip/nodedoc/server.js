
var express = require('express');
var app = express();
var server = require('http').createServer(app); //get library and create server
var bodyParser = require('body-parser');

var mysql = require('mysql');
var connection = mysql.createConnection({
host : 'localhost',
user : 'root',
password : 'cegep', //use your own password
database : 'LANMAKER'
});

//connect to database with the details we did provide
connection.connect(function(err){
      if(err){ 
           console.log('connection to database has failed');
           console.log(err.code);
      }
});

console.log('server is running on port 8080 …'); //this tell in the console that server is running

server.listen(process.env.PORT || 8080);
app.use(bodyParser.json()); //this serve json so we can send object to server
app.use(express.static( 'public' ));  //this serve the public folder
app.use(bodyParser.urlencoded({ extended: false}));

app.post('/test', function(request, response){
console.log('client did a request'); //print to console

	connection.query("SELECT * FROM tblUsers", function(err, result){
		response.send(result);
	});
});