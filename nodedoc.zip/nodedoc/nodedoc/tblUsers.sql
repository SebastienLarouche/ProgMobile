DROP DATABASE IF EXISTS LANMAKER;
CREATE DATABASE LANMAKER;
USE LANMAKER;

CREATE TABLE tblUsers
(
pseudo nvarchar(25) not null,
pass nvarchar(25) not null,
prenom varchar(25) not null,
nom varchar(25) not null,
age int not null, 
email nvarchar(50) not null
);
